import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime
from werkzeug.utils import secure_filename
import uuid

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'my-super-secret-key-123')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jobportal.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'auth'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    jobs_posted = db.relationship('Job', backref='employer', lazy=True, cascade="all, delete-orphan")
    applications = db.relationship('Application', backref='applicant', lazy=True, cascade="all, delete-orphan")

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(100), nullable=False)
    salary = db.Column(db.String(50))
    employer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    applications = db.relationship('Application', backref='job', lazy=True, cascade="all, delete-orphan")

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    seeker_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    resume_filename = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='Pending')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/auth')
def auth():
    role = request.args.get('role', 'seeker')
    mode = request.args.get('mode', 'login')
    return render_template('auth.html', role=role, mode=mode)

@app.route('/auth/process', methods=['POST'])
def auth_process():
    action = request.form.get('action')
    role = request.form.get('role')
    email = request.form.get('email')
    password = request.form.get('password')
    
    if action == 'signup':
        name = request.form.get('name')
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return redirect(url_for('auth', role=role, mode='signup'))
        new_user = User(name=name, email=email, password_hash=generate_password_hash(password), role=role)
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user)
        return redirect(url_for(f'dashboard_{role}'))
    
    elif action == 'login':
        user = User.query.filter_by(email=email, role=role).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for(f'dashboard_{role}'))
        flash('Invalid credentials')
        return redirect(url_for('auth', role=role, mode='login'))

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == 'admin' and password == 'admin':
            session['admin_logged_in'] = True
            return redirect(url_for('dashboard_admin'))
        flash('Invalid admin credentials')
    return render_template('admin_login.html')

@app.route('/logout')
def logout():
    if 'admin_logged_in' in session:
        session.pop('admin_logged_in', None)
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard/seeker')
@login_required
def dashboard_seeker():
    if current_user.role != 'seeker': return redirect(url_for('index'))
    applications = Application.query.filter_by(seeker_id=current_user.id).all()
    jobs = Job.query.order_by(Job.created_at.desc()).all()
    return render_template('dashboard_seeker.html', applications=applications, jobs=jobs)

@app.route('/dashboard/employer')
@login_required
def dashboard_employer():
    if current_user.role != 'employer': return redirect(url_for('index'))
    jobs = Job.query.filter_by(employer_id=current_user.id).all()
    return render_template('dashboard_employer.html', jobs=jobs)

@app.route('/dashboard/admin')
def dashboard_admin():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    users = User.query.all()
    jobs = Job.query.all()
    return render_template('dashboard_admin.html', users=users, jobs=jobs)

@app.route('/job/create', methods=['POST'])
@login_required
def create_job():
    if current_user.role != 'employer': return redirect(url_for('index'))
    title = request.form.get('title')
    description = request.form.get('description')
    location = request.form.get('location')
    salary = request.form.get('salary')
    new_job = Job(title=title, description=description, location=location, salary=salary, employer_id=current_user.id)
    db.session.add(new_job)
    db.session.commit()
    flash('Job posted successfully!')
    return redirect(url_for('dashboard_employer'))

@app.route('/job/<int:job_id>/apply', methods=['POST'])
@login_required
def apply_job(job_id):
    if current_user.role != 'seeker': return redirect(url_for('index'))
    if not Application.query.filter_by(job_id=job_id, seeker_id=current_user.id).first():
        resume_file = request.files.get('resume')
        filename = None
        if resume_file and resume_file.filename:
            filename = secure_filename(f"{uuid.uuid4().hex}_{resume_file.filename}")
            resume_file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            
        app_record = Application(job_id=job_id, seeker_id=current_user.id, resume_filename=filename)
        db.session.add(app_record)
        db.session.commit()
        flash('Applied successfully!')
    else:
        flash('You have already applied to this job.')
    return redirect(url_for('dashboard_seeker'))

@app.route('/job/<int:job_id>/applications')
@login_required
def job_applications(job_id):
    if current_user.role != 'employer': return redirect(url_for('index'))
    job = Job.query.get_or_404(job_id)
    if job.employer_id != current_user.id: return redirect(url_for('dashboard_employer'))
    return render_template('job_applications.html', job=job)

@app.route('/admin/delete_job/<int:job_id>')
def admin_delete_job(job_id):
    if not session.get('admin_logged_in'): return redirect(url_for('index'))
    job = Job.query.get_or_404(job_id)
    db.session.delete(job)
    db.session.commit()
    return redirect(url_for('dashboard_admin'))

@app.route('/admin/delete_user/<int:user_id>')
def admin_delete_user(user_id):
    if not session.get('admin_logged_in'): return redirect(url_for('index'))
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('dashboard_admin'))

if __name__ == '__main__':
    app.run(debug=True, port=5001)
