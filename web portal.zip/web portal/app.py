from flask import Flask, render_template, request, redirect, session
from models import db, User, Job, Application

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'secret123'
db.init_app(app)

@app.route('/')
def index():
    jobs = Job.query.all()
    return render_template('index.html', jobs=jobs)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user = User(
            username=request.form['username'],
            email=request.form['email'],
            password=request.form['password'],
            role=request.form['role']
        )
        db.session.add(user)
        db.session.commit()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(
            email=request.form['email'],
            password=request.form['password']
        ).first()
        if user:
            session['user_id'] = user.id
            session['role'] = user.role
            return redirect('/')
    return render_template('login.html')

@app.route('/post-job', methods=['GET', 'POST'])
def post_job():
    if request.method == 'POST':
        job = Job(
            title=request.form['title'],
            description=request.form['description'],
            salary=request.form['salary'],
            location=request.form['location'],
            company=request.form['company']
        )
        db.session.add(job)
        db.session.commit()
        return redirect('/')
    return render_template('post_job.html')

@app.route('/apply/<int:job_id>')
def apply(job_id):
    app = Application(
        user_id=session['user_id'],
        job_id=job_id
    )
    db.session.add(app)
    db.session.commit()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)